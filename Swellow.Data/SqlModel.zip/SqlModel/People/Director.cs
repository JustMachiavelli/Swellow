﻿
namespace Swellow.Data.SqlModel.People
{
    // 导演
    public class Director : Cast
    {

    }
}
