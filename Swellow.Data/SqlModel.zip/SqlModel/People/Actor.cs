﻿
namespace Swellow.Data.SqlModel.People
{
    // 演员
    public class Actor : Cast
    {

    }
}
