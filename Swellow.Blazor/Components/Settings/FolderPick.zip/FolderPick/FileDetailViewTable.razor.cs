﻿using Microsoft.AspNetCore.Components;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace Swellow.Blazor.Components.Settings.FolderPick
{
    public partial class FileDetailViewTable
    {
        private string selectedFile;

        [Parameter] public string SelectedDirectoryPath { get; set; }

        [Parameter] public DirectoryInfo[] IncludedDirectoryInfos { get; set; }

        [Parameter] public EventCallback<string> OnSelectedDirectory { get; set; }


        protected override Task OnParametersSetAsync()
        {
            return base.OnParametersSetAsync();
        }

        protected override Task OnAfterRenderAsync(bool firstRender)
        {
            return base.OnAfterRenderAsync(firstRender);
        }

        private Task SelectedDirectory(string path)
        {
            return OnSelectedDirectory.InvokeAsync(path);
        }
    }
}
