﻿using System.Threading.Tasks;
using System.IO;
using Microsoft.AspNetCore.Components;
using Swellow.Blazor.Services;

namespace Swellow.Blazor.Components.Settings.FolderPick
{
    public partial class FileExplorer
    {
        [Inject] public DiskService DiskService { get; set; }

        private string hostName;
        private DriveInfo[] driveInfos;
        private DirectoryInfo[] directoryInfos;
        private string selectedPath = null; // if the value is null, it means selected hostName(will show Drives)


        protected override async Task OnInitializedAsync()
        {
            hostName = await DiskService.GetHostName();
            driveInfos = await DiskService.GetDiskPreviewsAsync();
        }

        protected override void OnAfterRender(bool firstRender)
        {
            if (firstRender && driveInfos != null && driveInfos.Length > 0)
            {
                UpdateUIForHost();
            }
            base.OnAfterRender(firstRender);
        }

        private void UpdateUIForHost()
        {
            selectedPath = null;
            StateHasChanged();
        }

        private void MoveTo(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                UpdateUIForHost();
            }
            else
            {
                SetDirectoryItems(path);
            }
        }

        private async void SetDirectoryItems(string path)
        {
            selectedPath = path;
            directoryInfos = await DiskService.GetDirectoryInfos(selectedPath);
            await InvokeAsync(() => { this.StateHasChanged(); });
        }
    }
}
