﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Swellow.Blazor.Components.Settings.FolderPick
{
    public class DriveDetailView
    {
    }
}
